package LessonCalculator;

public interface Operation {

    double addition(double x, double y);

    double subtraction(double x, double y);

   double multiplication(double x, double y);

    double division(double x, double y);

}






